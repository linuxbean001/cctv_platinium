import { combineReducers } from "redux";
import cardItem from "./reducers";



export default combineReducers(
   
     {
   
     cardItem:cardItem,
   
     
})
