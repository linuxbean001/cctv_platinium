import RoutesMiddleware from "./Component/Routes/RoutesMiddleware";



function App() {
  return (

  <div className="App">
    <RoutesMiddleware/>  
  </div>
  );
}

export default App;
